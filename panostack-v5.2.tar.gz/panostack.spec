Name:           panostack
Version:        5.2
Release:        1
Summary:        Automated high-performance HQ RAW workflow utility

License:        GPLv3
URL:            https://github.com/user/panostack
# We gebruiken het losse script als bron
Source0:        panostack.py

BuildArch:      noarch
Requires:       python3 python3-pyside6 python3-opencv python3-numpy darktable hugin enblend-enfuse perl-Image-ExifTool ImageMagick

%description
PanoStack is een geautomatiseerde HQ RAW workflow utility.
Versie 5.2: Percentile Dynamic Stretching en Lab-CLAHE blending.

%prep
# Maak een lege build-map en kopieer het script daarheen
%setup -q -c -T
cp %{SOURCE0} .

%build
# Niets te doen

%install
mkdir -p %{buildroot}%{_bindir}
mkdir -p %{buildroot}%{_datadir}/applications

# Installeer het script vanuit de build-map naar de bin-map
install -m 0755 panostack.py %{buildroot}%{_bindir}/%{name}

# Desktop entry
cat > %{buildroot}%{_datadir}/applications/%{name}.desktop <<EOF
[Desktop Entry]
Name=PanoStack
Comment=Automated RAW Panorama & HDR Workflow
Exec=%{_bindir}/%{name}
Icon=photography
Terminal=false
Type=Application
Categories=Graphics;Photography;
EOF

%files
%{_bindir}/%{name}
%{_datadir}/applications/%{name}.desktop

%changelog
* Thu Aug 27 2026 Hans - 5.2-1
- Versie 5.2 met Percentile Dynamic Stretching.
