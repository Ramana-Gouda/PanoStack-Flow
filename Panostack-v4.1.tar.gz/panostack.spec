Name:           panostack
Version:        4.1
Release:        1%{?dist}
Summary:        Automated high-performance HQ RAW workflow utility
License:        GPLv3
URL:            https://github.com/yourusername/panostack
BuildArch:      noarch

# Op Arch negeren we de BuildRequires omdat we ze handmatig installeren via pacman
# BuildRequires: python3-devel

Requires:       python3
Requires:       python3-pyside6
Requires:       python3-opencv
Requires:       python3-numpy
Requires:       darktable
Requires:       hugin
Requires:       enblend-enfuse
Requires:       perl-Image-ExifTool
Requires:       ImageMagick

%description
PanoStack is een geautomatiseerde HQ RAW workflow utility voor fotografen.

%prep
mkdir -p %{_builddir}/%{name}-%{version}

%install
mkdir -p %{buildroot}%{_bindir}
install -m 0755 %{_sourcedir}/panostack.py %{buildroot}%{_bindir}/panostack

mkdir -p %{buildroot}%{_datadir}/icons/hicolor/256x256/apps
install -m 0644 %{_sourcedir}/panostack.png %{buildroot}%{_datadir}/icons/hicolor/256x256/apps/panostack.png

mkdir -p %{buildroot}%{_datadir}/applications
cat <<EOF > %{buildroot}%{_datadir}/applications/panostack.desktop
[Desktop Entry]
Name=PanoStack
Comment=HQ RAW Workflow & Panorama Stacker
Exec=panostack
Icon=panostack
Terminal=false
Type=Application
Categories=Graphics;Photography;
EOF

%files
%{_bindir}/panostack
%{_datadir}/applications/panostack.desktop
%{_datadir}/icons/hicolor/256x256/apps/panostack.png

%changelog
* ma aug 24 2026 Hans <hans@archlinux> - 4.1-1
- Fix date and file paths for Arch build
