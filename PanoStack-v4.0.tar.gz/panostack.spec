Name:           panostack
Version:        4.0
Release:        1%{?dist}
Summary:        Automated high-performance HQ RAW panorama workflow utility
BuildArch:      noarch

License:        GPLv3
URL:            https://jouw-website.nl
# Het bronbestand moet in de ~/rpmbuild/SOURCES map staan
Source0:        panostack.py

# Fedora/RPM Pakketnamen voor de afhankelijkheden
Requires:       python3
Requires:       python3-pyside6
Requires:       python3-opencv
Requires:       python3-numpy
Requires:       darktable
Requires:       hugin
Requires:       enblend
Requires:       perl-Image-ExifTool
Requires:       ImageMagick
Requires:       xcb-util-cursor

%description
PanoStack is an automated high-performance HQ RAW workflow utility
for professional photographers. It handles sorting, HDR stacking via
Enfuse, Burst noise reduction and Panorama stitching using Hugin or OpenCV.

%prep
# Geen voorbereiding nodig voor een enkel script

%install
# Maak de /usr/bin map aan in de tijdelijke bouwomgeving
mkdir -p %{buildroot}%{_bindir}

# Kopieer het script en hernoem het naar 'panostack' (zonder .py)
# We geven het direct permissie 755 (uitvoerbaar)
install -p -m 755 %{SOURCE0} %{buildroot}%{_bindir}/panostack

%files
# Geef aan welke bestanden bij dit pakket horen
%{_bindir}/panostack

%changelog
* Sun Aug 23 2026 Jouw Naam <jouw@email.nl> - 4.0-1
- Versie 4.0 release: HDR bit-depth selectie en OpenCV herstel.
